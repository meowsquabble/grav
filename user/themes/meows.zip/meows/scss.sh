#!/bin/sh
scss --watch scss:css
